package proj1;

public class NewClass {

	public NewClass() {
		// TODO Auto-generated constructor stub
	}

}
