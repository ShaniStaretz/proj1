package proj1;

public class M {

	public M() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		System.out.println("hello");

	}

}
